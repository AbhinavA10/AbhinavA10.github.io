
  # Second Portfolio Make

  This is a code bundle for Second Portfolio Make. The original project is available at https://www.figma.com/design/VLayH4UiXC8LbJXk5qSU34/Second-Portfolio-Make.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  