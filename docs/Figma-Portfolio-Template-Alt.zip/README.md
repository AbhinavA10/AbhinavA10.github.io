
  # Dark Themed Portfolio Page

  This is a code bundle for Dark Themed Portfolio Page. The original project is available at https://www.figma.com/design/Se1bjrhnRgloUwvJuLoeAl/Dark-Themed-Portfolio-Page.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  