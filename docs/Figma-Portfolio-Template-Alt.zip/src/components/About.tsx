import { Code2, Cpu, Cog } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { useScrollAnimation } from '../hooks/useScrollAnimation';

export function About() {
  const { ref: imageRef, isVisible: imageVisible } = useScrollAnimation();
  const { ref: contentRef, isVisible: contentVisible } = useScrollAnimation();

  const skills = [
    {
      icon: Code2,
      title: 'Software Development',
      description: 'Expert in C++, Python, and ROS for robotics applications',
    },
    {
      icon: Cpu,
      title: 'Computer Vision',
      description: 'Advanced perception systems using OpenCV and deep learning',
    },
    {
      icon: Cog,
      title: 'Control Systems',
      description: 'Motion planning, SLAM, and autonomous navigation',
    },
  ];

  return (
    <section id="about" className="py-20 bg-zinc-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          {/* Image */}
          <div
            ref={imageRef}
            className={`relative transition-all duration-1000 ${
              imageVisible ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-12'
            }`}
          >
            <div className="relative w-full aspect-square max-w-md mx-auto">
              <div className="absolute inset-0 bg-gradient-to-br from-orange-600/20 to-orange-400/20 rounded-2xl transform rotate-6"></div>
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1672685667592-0392f458f46f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBoZWFkc2hvdCUyMHBvcnRyYWl0fGVufDF8fHx8MTc2OTI4ODE3OXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Professional headshot"
                className="relative z-10 w-full h-full object-cover rounded-2xl shadow-2xl"
              />
            </div>
          </div>

          {/* Content */}
          <div
            ref={contentRef}
            className={`transition-all duration-1000 delay-200 ${
              contentVisible ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-12'
            }`}
          >
            <h2 className="text-4xl mb-6">
              About <span className="text-orange-500">Me</span>
            </h2>
            <p className="text-gray-300 text-lg mb-6">
              I'm a passionate robotics software engineer with a focus on creating intelligent,
              autonomous systems. With years of experience in the field, I specialize in developing
              robust software solutions that enable robots to perceive, reason, and interact with
              the world.
            </p>
            <p className="text-gray-300 text-lg mb-8">
              My work spans across various domains including autonomous navigation, computer vision,
              and human-robot interaction. I'm constantly exploring new technologies and
              methodologies to push the boundaries of what's possible in robotics.
            </p>

            {/* Skills Grid */}
            <div className="grid gap-6">
              {skills.map((skill, index) => (
                <div
                  key={index}
                  className={`flex items-start gap-4 p-4 bg-zinc-800/50 rounded-lg hover:bg-zinc-800 transition-all duration-500 ${
                    contentVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
                  }`}
                  style={{ transitionDelay: `${400 + index * 100}ms` }}
                >
                  <div className="p-2 bg-gradient-to-br from-orange-500/10 to-orange-500/10 rounded-lg">
                    <skill.icon className="text-orange-400" size={24} />
                  </div>
                  <div>
                    <h3 className="text-lg mb-1">{skill.title}</h3>
                    <p className="text-gray-400 text-sm">{skill.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}