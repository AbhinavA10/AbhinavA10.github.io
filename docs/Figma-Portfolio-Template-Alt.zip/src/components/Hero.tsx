import { ChevronDown } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

export function Hero() {
  const scrollToAbout = () => {
    const element = document.getElementById('about');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section
      id="hero"
      className="relative min-h-screen flex items-center overflow-hidden"
    >
      {/* Background Video */}
      <div className="absolute inset-0 z-0">
        <video
          autoPlay
          loop
          muted
          playsInline
          className="w-full h-full object-cover opacity-90"
        >
          <source
            src="https://assets.mixkit.co/videos/preview/mixkit-robotic-arm-assembling-parts-in-a-factory-4129-large.mp4"
            type="video/mp4"
          />
          {/* Fallback image if video doesn't load */}
          <ImageWithFallback
            src="https://images.unsplash.com/photo-1726244786561-522f88e8b813?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxyb2JvdGljcyUyMGVuZ2luZWVyJTIwd29ya2luZ3xlbnwxfHx8fDE3NjkzMjg0NzZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
            alt="Robotics engineer at work"
            className="w-full h-full object-cover"
          />
        </video>
      </div>

      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
        <div className="max-w-3xl backdrop-blur-xl bg-zinc-950/60 p-8 md:p-12 rounded-2xl border border-white/10">
          <h1 className="text-5xl sm:text-6xl lg:text-7xl mb-4 animate-fade-in font-display tracking-tight text-white">
            Your Name
          </h1>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl mb-6 text-orange-500">
            Robotics Software Engineer
          </h2>
          <p className="text-lg sm:text-xl text-gray-300">
            Building intelligent systems that bridge the gap between code and the physical world
          </p>
          <div className="flex flex-col sm:flex-row gap-4 mt-8">
            <button
              onClick={scrollToAbout}
              className="px-8 py-3 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-colors shadow-lg shadow-orange-600/30"
            >
              Learn More
            </button>
            <button
              onClick={() => document.getElementById('projects')?.scrollIntoView({ behavior: 'smooth' })}
              className="px-8 py-3 bg-transparent border-2 border-orange-500 text-orange-400 rounded-lg hover:bg-orange-500/10 transition-colors"
            >
              View Projects
            </button>
          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <button
        onClick={scrollToAbout}
        className="absolute bottom-8 left-1/2 transform -translate-x-1/2 z-10 animate-bounce text-orange-400 hover:text-orange-300 transition-colors"
      >
        <ChevronDown size={32} />
      </button>
    </section>
  );
}