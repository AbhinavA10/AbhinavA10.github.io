import { X } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface ProjectModalProps {
  project: {
    title: string;
    description: string;
    image: string;
    tags: string[];
    longDescription?: string;
    features?: string[];
    technologies?: string[];
    github?: string;
    demo?: string;
    media?: string[];
  };
  onClose: () => void;
}

export function ProjectModal({ project, onClose }: ProjectModalProps) {
  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        className="relative bg-zinc-900 rounded-lg max-w-7xl w-full max-h-[90vh] overflow-y-auto border border-zinc-800 shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-10 p-2 bg-zinc-800 rounded-full hover:bg-zinc-700 transition-colors"
        >
          <X size={20} className="text-gray-300" />
        </button>

        {/* Hero Image */}
        <div className="relative h-64 md:h-96 overflow-hidden rounded-t-lg">
          <ImageWithFallback
            src={project.image}
            alt={project.title}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-zinc-900 to-transparent"></div>
        </div>

        {/* Content */}
        <div className="p-6 md:p-8">
          <div className="grid md:grid-cols-3 gap-8">
            {/* Main Content - Left 2/3 */}
            <div className="md:col-span-2">
              <h2 className="text-3xl md:text-4xl mb-4">
                {project.title}
              </h2>

              {/* Tags */}
              <div className="flex flex-wrap gap-2 mb-6">
                {project.tags.map((tag, i) => (
                  <span
                    key={i}
                    className="px-3 py-1 bg-gradient-to-r from-blue-500/10 to-teal-500/10 text-blue-400 text-sm rounded-full border border-blue-500/20"
                  >
                    {tag}
                  </span>
                ))}
              </div>

              {/* Description */}
              <p className="text-gray-300 text-lg mb-6">{project.description}</p>

              {/* Long Description */}
              {project.longDescription && (
                <div className="mb-6">
                  <h3 className="text-xl mb-3 text-blue-400">Project Overview</h3>
                  <p className="text-gray-400 leading-relaxed">{project.longDescription}</p>
                </div>
              )}

              {/* Features */}
              {project.features && project.features.length > 0 && (
                <div className="mb-6">
                  <h3 className="text-xl mb-3 text-blue-400">Key Features</h3>
                  <ul className="space-y-2">
                    {project.features.map((feature, i) => (
                      <li key={i} className="text-gray-300 flex items-start gap-2">
                        <span className="text-blue-400 mt-1">•</span>
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Media Grid */}
              {project.media && project.media.length > 0 && (
                <div className="mb-6">
                  <h3 className="text-xl mb-3 text-blue-400">Project Media</h3>
                  <div className="grid grid-cols-2 gap-4">
                    {project.media.map((mediaUrl, i) => (
                      <div key={i} className="rounded-lg overflow-hidden aspect-video">
                        <ImageWithFallback
                          src={mediaUrl}
                          alt={`${project.title} screenshot ${i + 1}`}
                          className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                        />
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Sidebar - Right 1/3 */}
            <div className="md:col-span-1">
              {/* Technologies */}
              {project.technologies && project.technologies.length > 0 && (
                <div className="mb-6 bg-zinc-800/50 p-6 rounded-lg">
                  <h3 className="text-xl mb-3 text-blue-400">Technologies</h3>
                  <div className="flex flex-wrap gap-2">
                    {project.technologies.map((tech, i) => (
                      <span
                        key={i}
                        className="px-3 py-1 bg-zinc-700 text-gray-300 text-sm rounded"
                      >
                        {tech}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {/* Links */}
              <div className="space-y-3">
                {project.github && (
                  <a
                    href={project.github}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="block w-full px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-center"
                  >
                    View on GitHub
                  </a>
                )}
                {project.demo && (
                  <a
                    href={project.demo}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="block w-full px-6 py-3 bg-transparent border-2 border-blue-500 text-blue-400 rounded-lg hover:bg-blue-500/10 transition-colors text-center"
                  >
                    Live Demo
                  </a>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
