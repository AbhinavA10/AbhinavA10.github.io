import { Hero } from './components/Hero';
import { About } from './components/About';
import { Experience } from './components/Experience';
import { Projects } from './components/Projects';
import { Navigation } from './components/Navigation';

export default function App() {
  return (
    <div className="min-h-screen bg-zinc-950 text-white">
      <Navigation />
      <Hero />
      <About />
      <Experience />
      <Projects />
    </div>
  );
}
